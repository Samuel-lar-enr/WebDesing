# 📦 Pack de Ejercicios: Repaso HTML5 y CSS

## 📚 Contenido del Pack

Este pack contiene **3 ejercicios prácticos** y **1 proyecto integrador**.

### **Ejercicios Prácticos**

1. **Ejercicio 1:** Transforma el DIV 
2. **Ejercicio 2:** Cajas con Box Model 
3. **Ejercicio 3:** Formulario Estilizado 

### **Proyecto Final**

1. **Proyecto:** Tarjeta de Presentación Personal 

---

## 📂 Estructura de Archivos

```
ejercicios_html_css/
│
├── README.md (este archivo)
│
├── ejercicio_1_transforma_div/
│   ├── instrucciones.md
│   └── plantilla_base.html
│
├── ejercicio_2_cajas_box_model/
│   ├── instrucciones.md
│   └── plantilla_base.html
│
├── ejercicio_3_formulario/
│   ├── instrucciones.md
│   └── plantilla_base.html
│
└── proyecto_final_tarjeta/
    ├── especificaciones.md
    └── rubrica_evaluacion.md
```

---

## 🎯 Objetivos de Aprendizaje

Al completar estos ejercicios y el proyecto, los alumnos serán capaces de:

✅ Utilizar **etiquetas semánticas** de HTML5 correctamente
✅ Entender y aplicar el **modelo de caja** CSS
✅ Calcular dimensiones con `content-box` y `border-box`
✅ Usar **selectores CSS** (clase, ID, descendente, pseudo-clases)
✅ Aplicar **validación nativa** en formularios HTML5
✅ Estilizar formularios con **pseudo-clases** (`:valid`, `:invalid`, `:focus`)
✅ Validar código con **W3C Validator**
✅ Crear una página web completa con estructura semántica

---

## 📝 Sistema de Evaluación

### **Semana 1: Ejercicios Prácticos (30%)**
- Ejercicio 1: 10%
- Ejercicio 2: 10%
- Ejercicio 3: 10%

### **Semana 2: Proyecto Final (70%)**
- HTML semántico correcto: 20%
- CSS aplicado (modelo de caja, selectores): 25%
- Formulario con validación: 15%
- Validación W3C (HTML + CSS): 10%

---

## 🛠️ Herramientas Necesarias

- **Editor de código:** Visual Studio Code, Sublime Text, o similar
- **Navegador moderno:** Chrome, Firefox, Edge
- **Validadores:**
  - HTML: https://validator.w3.org/
  - CSS: https://jigsaw.w3.org/css-validator/
- **DevTools del navegador** (F12)

---

## 📖 Material de Consulta

- Documento de repaso HTML5 y CSS (proporcionado por el profesor)
- MDN Web Docs: https://developer.mozilla.org/es/
- Can I Use: https://caniuse.com/

---


## ✅ Checklist de Entrega

Antes de entregar cualquier ejercicio o proyecto, verifica:

- [ ] El código HTML pasa la validación W3C
- [ ] El código CSS pasa la validación W3C
- [ ] La página se ve correctamente en el navegador
- [ ] Has usado las etiquetas semánticas apropiadas
- [ ] Los nombres de archivos son correctos
- [ ] Has incluido comentarios en el código donde sea necesario

---

## 💡 Consejos

1. **Lee bien las instrucciones** antes de empezar a programar
2. **Usa DevTools** (F12) para inspeccionar y depurar tu código
3. **Valida frecuentemente** tu código mientras trabajas
4. **Pregunta dudas** al profesor durante las sesiones
5. **Guarda tu trabajo** regularmente
6. **Compara con el resultado esperado** antes de entregar

---

## 📧 Entrega de Ejercicios

**Formato de entrega:**
- Carpeta comprimida (.zip) con el nombre: `Apellido_Nombre_EjercicioX.zip`
- Incluir todos los archivos necesarios (HTML, CSS, imágenes si las hay)

**Plataforma:** Moodle

---

¡Buena suerte con los ejercicios! 🚀
